import * as THREE from 'three';
import './style.css';

const app = document.querySelector('#app');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x91d9d0);
scene.fog = new THREE.Fog(0x91d9d0, 28, 105);
const camera = new THREE.PerspectiveCamera(58, innerWidth/innerHeight, .1, 180);
camera.position.set(0, 5.2, 10.5);
const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
app.prepend(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xdafcff,0x42613a,2.0));
const sun = new THREE.DirectionalLight(0xfff0c9,2.1); sun.position.set(-8,15,8); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024); scene.add(sun);

const mat=(color,roughness=1)=>new THREE.MeshStandardMaterial({color,roughness});
const grass=mat(0x39834e), roadMat=mat(0x777c76), laneMat=mat(0xe7dfb8), rockMat=mat(0x696d61), woodMat=mat(0x805331), coinMat=new THREE.MeshStandardMaterial({color:0xffc928,metalness:.7,roughness:.25}), shirtMat=mat(0xe94e35), skinMat=mat(0xc98d62), darkMat=mat(0x263b35);
const world=new THREE.Group();scene.add(world);
const road=new THREE.Mesh(new THREE.BoxGeometry(8,.25,150),roadMat);road.position.set(0,-.18,-48);road.receiveShadow=true;world.add(road);
const sideGround=new THREE.Mesh(new THREE.BoxGeometry(90,.3,150),grass);sideGround.position.set(0,-.48,-48);world.add(sideGround);
for(let x of [-4.25,4.25]){const edge=new THREE.Mesh(new THREE.BoxGeometry(.22,.18,150),mat(0xd9d0ad));edge.position.set(x,-.02,-48);world.add(edge)}
// Layered mountain silhouettes
for(let layer=0;layer<3;layer++){
  for(let i=0;i<13;i++){
    const h=8+Math.random()*12-layer*2, w=9+Math.random()*10;
    const geo=new THREE.ConeGeometry(w,h,5);
    const m=new THREE.Mesh(geo,mat([0x28694d,0x3d895c,0x6aa477][layer]));
    m.position.set((i-6)*13+(layer%2)*5,h/2-1,-78-layer*13);
    m.rotation.y=Math.random()*1;scene.add(m);
  }
}
// Trees along both sides
function tree(x,z,scale=1){
 const g=new THREE.Group();
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.12*scale,.2*scale,1.5*scale,6),woodMat);trunk.position.y=.7*scale;trunk.castShadow=true;g.add(trunk);
 for(let j=0;j<3;j++){const crown=new THREE.Mesh(new THREE.ConeGeometry((1.05-j*.17)*scale,1.8*scale,7),mat([0x1d6844,0x28794a,0x3d8c52][j]));crown.position.y=(1.55+j*.65)*scale;crown.castShadow=true;g.add(crown)}
 g.position.set(x,0,z);world.add(g);return g;
}
for(let z=5;z>-125;z-=5.5){tree(-5.8-Math.random()*2,z,.8+Math.random()*.7);tree(5.8+Math.random()*2,z,.8+Math.random()*.7)}
// Distant waterfall ribbon
const water=new THREE.Mesh(new THREE.PlaneGeometry(2.1,8),new THREE.MeshBasicMaterial({color:0x9cecff,transparent:true,opacity:.8}));water.position.set(-17,5,-40);scene.add(water);
// Runner
const player=new THREE.Group();scene.add(player);
const torso=new THREE.Mesh(new THREE.BoxGeometry(.72,1,.42),shirtMat);torso.position.y=1.35;torso.castShadow=true;player.add(torso);
const head=new THREE.Mesh(new THREE.SphereGeometry(.31,12,10),skinMat);head.position.y=2.12;head.castShadow=true;player.add(head);
const hair=new THREE.Mesh(new THREE.SphereGeometry(.32,10,8,0,Math.PI*2,0,Math.PI*.55),darkMat);hair.position.y=2.23;player.add(hair);
const legs=[];
for(let x of [-.22,.22]){const leg=new THREE.Mesh(new THREE.BoxGeometry(.24,.75,.27),darkMat);leg.position.set(x,.48,0);player.add(leg);legs.push(leg)}
const arms=[];
for(let x of [-.48,.48]){const arm=new THREE.Mesh(new THREE.BoxGeometry(.2,.72,.22),shirtMat);arm.position.set(x,1.35,0);player.add(arm);arms.push(arm)}
player.position.z=2;
const objects=[];let lane=0, targetX=0, running=false, paused=false, score=0, coins=0, distance=0, speed=17, spawnTimer=0, jumpV=0, sliding=0, shield=0;
const ui={menu:document.querySelector('#menu'),hud:document.querySelector('#hud'),over:document.querySelector('#over'),pause:document.querySelector('#pauseScreen'),score:document.querySelector('#score'),coins:document.querySelector('#coins'),distance:document.querySelector('#distance')};
const bestEl=document.querySelector('#best');bestEl.textContent=localStorage.getItem('bpr-best')||0;
function makeObstacle(type,lane,z){
 const g=new THREE.Group();let mesh;
 if(type==='rock'){mesh=new THREE.Mesh(new THREE.DodecahedronGeometry(.72,0),rockMat);mesh.position.y=.65;mesh.scale.set(1,1,.85)}
 else if(type==='log'){mesh=new THREE.Mesh(new THREE.CylinderGeometry(.22,.25,2.4,8),woodMat);mesh.rotation.z=Math.PI/2;mesh.position.y=.55}
 else {mesh=new THREE.Mesh(new THREE.BoxGeometry(2.1,.8,.35),woodMat);mesh.position.y=.55}
 mesh.castShadow=true;g.add(mesh);g.position.set(lane*2.25,0,z);scene.add(g);objects.push({mesh:g,type,lane,kind:'obstacle',passed:false});
}
function makeCoin(lane,z){const c=new THREE.Mesh(new THREE.TorusGeometry(.34,.12,8,16),coinMat);c.position.set(lane*2.25,1.25,z);c.rotation.y=Math.PI/2;scene.add(c);objects.push({mesh:c,kind:'coin'})}
function spawn(){
 const l=Math.floor(Math.random()*3)-1;
 const r=Math.random();
 if(r<.48)makeObstacle(r<.23?'rock':r<.36?'log':'barrier',l,-72);
 else {for(let i=0;i<5;i++)makeCoin(l,-68-i*2.3)}
 if(Math.random()<.35){const l2=[-1,0,1].filter(v=>v!==l)[Math.floor(Math.random()*2)];for(let i=0;i<3;i++)makeCoin(l2,-83-i*2.3)}
}
function clearObjects(){for(const o of objects)scene.remove(o.mesh);objects.length=0}
function start(){clearObjects();lane=0;targetX=0;player.position.set(0,0,2);score=0;coins=0;distance=0;speed=17;spawnTimer=.5;jumpV=0;sliding=0;shield=0;running=true;paused=false;ui.menu.classList.add('hidden');ui.over.classList.add('hidden');ui.pause.classList.add('hidden');ui.hud.classList.remove('hidden');document.querySelector('#touchHelp').classList.remove('hidden');updateHUD()}
function endGame(){running=false;ui.hud.classList.add('hidden');document.querySelector('#finalScore').textContent=Math.floor(score);document.querySelector('#finalCoins').textContent=coins;const best=Math.max(Math.floor(score),Number(localStorage.getItem('bpr-best')||0));localStorage.setItem('bpr-best',best);bestEl.textContent=best;ui.over.classList.remove('hidden')}
function updateHUD(){ui.score.textContent=Math.floor(score);ui.coins.textContent=coins;ui.distance.textContent=Math.floor(distance)}
function move(d){if(!running||paused)return;lane=Math.max(-1,Math.min(1,lane+d));targetX=lane*2.25}
function jump(){if(running&&!paused&&player.position.y<.03){jumpV=9.5;sliding=0;player.scale.y=1}}
function slide(){if(running&&!paused&&player.position.y<.05){sliding=.65}}
function actKey(e){if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key))e.preventDefault();if(e.key==='ArrowLeft'||e.key.toLowerCase()==='a')move(-1);if(e.key==='ArrowRight'||e.key.toLowerCase()==='d')move(1);if(e.key==='ArrowUp'||e.key.toLowerCase()==='w'||e.key===' ')jump();if(e.key==='ArrowDown'||e.key.toLowerCase()==='s')slide();if(e.key==='Escape'&&running)togglePause()}
addEventListener('keydown',actKey);
let sx=0,sy=0;renderer.domElement.addEventListener('touchstart',e=>{sx=e.changedTouches[0].clientX;sy=e.changedTouches[0].clientY},{passive:true});
renderer.domElement.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-sx,dy=e.changedTouches[0].clientY-sy;if(Math.max(Math.abs(dx),Math.abs(dy))<25)return;if(Math.abs(dx)>Math.abs(dy))move(dx>0?1:-1);else if(dy<0)jump();else slide()},{passive:true});
function togglePause(){if(!running)return;paused=!paused;ui.pause.classList.toggle('hidden',!paused)}
document.querySelector('#play').onclick=start;document.querySelector('#again').onclick=start;document.querySelector('#resume').onclick=()=>{paused=false;ui.pause.classList.add('hidden')};document.querySelector('#restart').onclick=start;document.querySelector('#pause').onclick=togglePause;document.querySelector('#home').onclick=()=>{running=false;ui.over.classList.add('hidden');ui.menu.classList.remove('hidden')};

const clock=new THREE.Clock();
function animate(){
 requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04),t=clock.elapsedTime;
 if(running&&!paused){
  distance+=speed*dt/3;score+=speed*dt*.7;speed=Math.min(29,17+distance*.018);
  spawnTimer-=dt;if(spawnTimer<=0){spawn();spawnTimer=Math.max(.62,1.12-(speed-17)*.025)+Math.random()*.25}
  player.position.x=THREE.MathUtils.damp(player.position.x,targetX,13,dt);
  if(jumpV!==0||player.position.y>0){jumpV-=23*dt;player.position.y+=jumpV*dt;if(player.position.y<=0){player.position.y=0;jumpV=0}}
  if(sliding>0){sliding-=dt;player.scale.y=THREE.MathUtils.damp(player.scale.y,.48,20,dt)}else player.scale.y=THREE.MathUtils.damp(player.scale.y,1,15,dt);
  legs.forEach((l,i)=>l.rotation.x=Math.sin(t*speed*.65+i*Math.PI)*.8);arms.forEach((a,i)=>a.rotation.x=Math.sin(t*speed*.65+i*Math.PI+Math.PI)*.65);
  for(let i=objects.length-1;i>=0;i--){
   const o=objects[i];o.mesh.position.z+=speed*dt;if(o.kind==='coin')o.mesh.rotation.z+=dt*4;
   if(o.mesh.position.z>5){scene.remove(o.mesh);objects.splice(i,1);continue}
   if(Math.abs(o.mesh.position.z-player.position.z)<.85&&Math.abs(o.mesh.position.x-player.position.x)<1.15){
    if(o.kind==='coin'){coins++;score+=30;scene.remove(o.mesh);objects.splice(i,1);continue}
    const safeJump=player.position.y>.85,safeSlide=sliding>0&&o.type==='barrier';
    if(!safeJump&&!safeSlide){endGame();break}
   }
  }
  updateHUD();
 }
 // Animated clouds and camera
 camera.position.x=THREE.MathUtils.damp(camera.position.x,player.position.x*.18,2.5,dt);
 camera.lookAt(player.position.x*.12,1.2,-5);
 water.position.y=5+Math.sin(t*.7)*.15;
 renderer.render(scene,camera);
}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.7))});
