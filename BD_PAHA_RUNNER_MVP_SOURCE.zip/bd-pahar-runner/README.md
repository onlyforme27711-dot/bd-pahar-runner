# BD PAHAR RUNNER 🇧🇩

A first playable 3D endless-runner MVP inspired by Bangladesh's hill landscapes.

## Features in this MVP
- Three-lane endless running
- Keyboard and mobile swipe controls
- Jump, slide, coins, obstacles and collision
- Procedural low-poly green mountain scenery
- Score, distance and saved best score
- Responsive browser build
- Capacitor Android project configuration

## Requirements
- Node.js 20 or newer
- Android Studio + Android SDK (for APK)
- Java/JDK supported by your installed Android Gradle Plugin

## Run on PC / browser
```bash
npm install
npm run dev
```
Open the local URL shown by Vite.

## Build browser version
```bash
npm run build
npm run preview
```

## Create Android project
Run these commands from this project folder:
```bash
npm install
npx cap add android
npm run android:sync
npx cap open android
```
In Android Studio, wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The debug APK is normally created at:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Important
This source package is the playable MVP project, not a precompiled APK. An Android SDK/Gradle build environment is required to compile the APK. Do not rename the browser build and call it an APK.

## Controls
- Left / Right arrows or A / D: change lane
- Up / W / Space: jump
- Down / S: slide
- Mobile: swipe in the desired direction
- Escape: pause
